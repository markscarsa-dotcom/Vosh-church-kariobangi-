const express = require('express');
const axios = require('axios');
const dotenv = require('dotenv');
const path = require('path');

dotenv.config();

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '100kb' }));
app.use(express.static(__dirname, { extensions: ['html'] }));

const PORT = Number(process.env.PORT || 3000);
const DARAJA_ENV = (process.env.DARAJA_ENV || 'production').toLowerCase();
const DARAJA_BASE = DARAJA_ENV === 'production'
  ? 'https://api.safaricom.co.ke'
  : 'https://sandbox.safaricom.co.ke';

function normalizePhone(phone) {
  const p = String(phone || '').replace(/\s+/g, '');
  if (/^07\d{8}$/.test(p)) return `254${p.slice(1)}`;
  if (/^\+2547\d{8}$/.test(p)) return p.slice(1);
  if (/^2547\d{8}$/.test(p)) return p;
  throw new Error('Invalid Kenyan M-Pesa phone number');
}

function requiredConfig() {
  return ['DARAJA_CONSUMER_KEY','DARAJA_CONSUMER_SECRET','DARAJA_SHORTCODE','DARAJA_PASSKEY','CALLBACK_URL'];
}

function assertConfig() {
  const missing = requiredConfig().filter((key) => !process.env[key]);
  if (missing.length) throw new Error(`Missing server configuration: ${missing.join(', ')}`);
  if (DARAJA_ENV === 'production' && !/^https:\/\//i.test(process.env.CALLBACK_URL)) {
    throw new Error('CALLBACK_URL must be a public HTTPS URL in production.');
  }
}

async function getAccessToken() {
  const auth = Buffer.from(
    `${process.env.DARAJA_CONSUMER_KEY}:${process.env.DARAJA_CONSUMER_SECRET}`
  ).toString('base64');

  const response = await axios.get(
    `${DARAJA_BASE}/oauth/v1/generate?grant_type=client_credentials`,
    { headers: { Authorization: `Basic ${auth}` }, timeout: 15000 }
  );
  return response.data.access_token;
}

app.post('/api/mpesa/stkpush', async (req, res) => {
  try {
    assertConfig();

    const phone = normalizePhone(req.body.phone);
    const amount = Math.floor(Number(req.body.amount));
    const allowedAccounts = new Set(['TITHE','SADAKA','LOVE','ENDYEAR']);
    const account = allowedAccounts.has(String(req.body.account)) ? String(req.body.account) : 'GIVING';

    if (!Number.isFinite(amount) || amount < 1 || amount > 150000) {
      return res.status(400).json({ error: 'Amount must be between KES 1 and KES 150,000.' });
    }

    const token = await getAccessToken();
    const timestamp = new Date().toISOString().replace(/[-:TZ.]/g, '').slice(0, 14);
    const password = Buffer.from(
      `${process.env.DARAJA_SHORTCODE}${process.env.DARAJA_PASSKEY}${timestamp}`
    ).toString('base64');

    const payload = {
      BusinessShortCode: process.env.DARAJA_SHORTCODE,
      Password: password,
      Timestamp: timestamp,
      TransactionType: process.env.DARAJA_TRANSACTION_TYPE || 'CustomerPayBillOnline',
      Amount: amount,
      PartyA: phone,
      PartyB: process.env.DARAJA_SHORTCODE,
      PhoneNumber: phone,
      CallBackURL: process.env.CALLBACK_URL,
      AccountReference: account,
      TransactionDesc: 'VOSH Church giving'
    };

    const response = await axios.post(
      `${DARAJA_BASE}/mpesa/stkpush/v1/processrequest`,
      payload,
      { headers: { Authorization: `Bearer ${token}` }, timeout: 20000 }
    );

    return res.status(200).json(response.data);
  } catch (err) {
    const detail = err.response?.data || err.message;
    console.error('STK Push error:', detail);
    return res.status(500).json({
      error: 'Unable to start M-Pesa STK Push.',
      errorMessage: typeof detail === 'string' ? detail : detail?.errorMessage,
      ResponseCode: typeof detail === 'object' ? detail?.ResponseCode : undefined
    });
  }
});

app.post('/api/mpesa/callback', (req, res) => {
  console.log('M-Pesa callback:', JSON.stringify(req.body, null, 2));
  return res.json({ ResultCode: 0, ResultDesc: 'Accepted' });
});

app.get('/health', (_req, res) => res.json({ ok: true, daraja: DARAJA_ENV }));

app.get('/', (_req, res) => {
  res.sendFile(path.join(__dirname, 'VOSH_Church_Intl_Kariobangi.html'));
});

app.listen(PORT, () => {
  console.log(`VOSH Church website running on port ${PORT}`);
  console.log(`Daraja environment: ${DARAJA_ENV}`);
});
